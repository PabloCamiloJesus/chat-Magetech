import styled from "styled-components";
import SplashLogo from "../../assets/logo-sem-fundo.png";
import Split1 from "../../assets/Splash-Splits/Split1_T.png";
import Split2 from "../../assets/Splash-Splits/Split2_E.png";
import Split3 from "../../assets/Splash-Splits/Split3_C.png";
import Split4 from "../../assets/Splash-Splits/Split4_H.png";
import Split5 from "../../assets/Splash-Splits/Split5_M.png";
import Split6 from "../../assets/Splash-Splits/Split6_A.png";
import Split7 from "../../assets/Splash-Splits/Split7_G.png";
import Split8 from "../../assets/Splash-Splits/Split8_E.png";
import "./Splash.css";


export default function Splash() {
        
        const imgSplash = document.querySelector(".img-splash");
    
        // Verifica se a imagem foi encontrada
        if (imgSplash) {
            imgSplash.style.opacity = "1";

        };

        const textSplash = document.querySelector(".text-splash");
    
        // Verifica se a imagem foi encontrada
        if (textSplash) {
            textSplash.style.opacity = "1";

        };
    
    

    return (
        <div>

            <div className="splash-container">

                <div className="splash-img">
                    <img src={SplashLogo} alt="" className="img-splash" />
                </div>

                <div className="splash-text">
                    <img src={Split1} alt="" className="text-splash"/>
                    <img src={Split2} alt="" className="text-splash" />
                    <img src={Split3} alt="" className="text-splash" />
                    <img src={Split4} alt="" className="text-splash" />
                    <img src={Split5} alt="" className="text-splash" />
                    <img src={Split6} alt="" className="text-splash" />
                    <img src={Split7} alt="" className="text-splash" />
                    <img src={Split8} alt="" className="text-splash" />
                </div>

            </div>

        </div>
    )
}